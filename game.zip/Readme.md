# dxDD2RenPy_Example
Example of using dxDD2RenPy:
https://github.com/DeXP/dxDD2RenPy

# 3rd party
Game files (json) generated with Dialogue Designer tool:
https://store.steampowered.com/app/1273620/Dialogue_Designer/

![dxDD2RenPy_Example MainMenu](game/images/MainMenu.jpg)